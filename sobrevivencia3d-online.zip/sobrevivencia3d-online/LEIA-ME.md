# Sobrevivência 3D — online + Android

Tem 3 partes: **server/** (servidor + jogo), **server/public/** (o jogo, instalável como app) e **apk/** (gera o `.apk`).

## 1) Ligar o servidor (modo online)
Precisa só do Node.js (18+). Sem instalar nada:

    cd server
    node server.js

Ele mostra o endereço na rede local, ex.: `http://192.168.0.10:3000`.
- Mundo e construções ficam salvos em `server/world.json` (apague o arquivo para criar um mundo novo).
- Até 16 jogadores. Cada um vê os outros, o mesmo mapa e as construções dos amigos.
- Os animais ainda são locais (cada um vê os seus).

### Jogar com amigos
- **Mesma rede Wi-Fi:** todos abrem `http://IP-DO-PC:3000` no navegador do celular, ou usam o APK e digitam `ws://IP-DO-PC:3000`.
- **Pela internet:** coloque a pasta `server/` em qualquer hospedagem Node (Render, Railway, Fly.io…; comando de início `node server.js`). Eles te dão um endereço `https://seu-jogo.onrender.com`; no jogo use `wss://seu-jogo.onrender.com`.

No jogo: **Jogar online 🌐** → confira o endereço → apelido → **Entrar**.

## 2) Instalar como app, sem APK (PWA)
Com o servidor numa hospedagem **https**, abra o endereço no Chrome do Android → menu ⋮ → **Instalar app** (ou "Adicionar à tela inicial"). Vira um ícone em tela cheia e funciona offline no modo solo.

## 3) Gerar o APK de verdade
**Opção A (mais fácil, sem instalar nada):** com o servidor em https, vá em https://www.pwabuilder.com, cole o endereço, clique em **Package for stores → Android** e baixe o APK.

**Opção B (no seu computador):** instale Node, JDK 17 e o Android Studio (traz o Android SDK), depois:

    cd apk
    ./build.sh

O APK sai em `apk/android/app/build/outputs/apk/debug/app-debug.apk`. Copie para o celular e instale (permita "fontes desconhecidas"). Esse APK guarda o jogo dentro dele; para o online, digite o endereço do seu servidor (`ws://...` na rede local, `wss://...` na internet).

## Controles
Joy-Con/controle, teclado+mouse e toque na tela (veja o menu do jogo). Em Opções › Configurar botões dá para remapear o controle.
