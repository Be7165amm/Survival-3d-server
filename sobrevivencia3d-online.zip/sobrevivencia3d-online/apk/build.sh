#!/usr/bin/env bash
# Gera o APK (debug, instalável direto no Android). Requisitos: Node 18+, JDK 17 e Android SDK (Android Studio).
set -e
cd "$(dirname "$0")"
npm install
[ -d android ] || npx cap add android
# trava a tela na horizontal
sed -i 's/<activity /<activity android:screenOrientation="sensorLandscape" /' android/app/src/main/AndroidManifest.xml 2>/dev/null || true
npx cap sync android
cd android && ./gradlew assembleDebug
echo; echo "APK pronto em: apk/android/app/build/outputs/apk/debug/app-debug.apk"
