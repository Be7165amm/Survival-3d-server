// Servidor do Sobrevivência 3D — sem dependências. Uso: node server.js  (porta 3000, ou PORT=xxxx)
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto'),os=require('os');
const PORT=+process.env.PORT||3000,PUB=path.join(__dirname,'public'),SAVE=path.join(__dirname,'world.json'),MAXP=16;
let world={seed:Math.floor(Math.random()*2147483647),blocks:{}};
try{const w=JSON.parse(fs.readFileSync(SAVE,'utf8'));if(w&&w.seed!=null&&w.blocks)world=w}catch(_){}
let dirty=false;setInterval(()=>{if(dirty){dirty=false;fs.writeFile(SAVE,JSON.stringify(world),()=>{})}},15000);
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript','.json':'application/json','.webmanifest':'application/manifest+json','.png':'image/png'};
const server=http.createServer((req,res)=>{
 let u=decodeURIComponent(req.url.split('?')[0]);if(u=='/')u='/index.html';
 const f=path.join(PUB,path.normalize(u));if(!f.startsWith(PUB)){res.writeHead(403);return res.end()}
 fs.readFile(f,(e,d)=>{if(e){res.writeHead(404);return res.end('404')}res.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});res.end(d)})});
const clients=new Map();let nextId=1;
function frame(op,data){const n=data.length;let h;if(n<126)h=Buffer.from([0x80|op,n]);else if(n<65536){h=Buffer.alloc(4);h[0]=0x80|op;h[1]=126;h.writeUInt16BE(n,2)}else{h=Buffer.alloc(10);h[0]=0x80|op;h[1]=127;h.writeBigUInt64BE(BigInt(n),2)}return Buffer.concat([h,data])}
function send(c,obj){if(!c.socket.destroyed)c.socket.write(frame(1,Buffer.from(JSON.stringify(obj))))}
function bcast(obj,except){const f=frame(1,Buffer.from(JSON.stringify(obj)));for(const c of clients.values())if(c!==except&&!c.socket.destroyed)c.socket.write(f)}
function drop(c){if(c.dead)return;c.dead=true;if(c.joined&&clients.delete(c.id))bcast({t:'leave',id:c.id});try{c.socket.destroy()}catch(_){}}
function handle(c,txt){
 if(Date.now()-c.win>1000){c.win=Date.now();c.cnt=0}if(++c.cnt>120)return;
 let m;try{m=JSON.parse(txt)}catch(_){return}
 if(m.t=='join'&&!c.joined){
  if(clients.size>=MAXP){send(c,{t:'full'});c.socket.end();return}
  c.id=nextId++;c.name=String(m.name||'Jogador').replace(/[<>&"]/g,'').slice(0,16)||'Jogador';c.joined=true;
  const players=[...clients.values()].map(o=>({id:o.id,name:o.name,x:o.x,y:o.y,z:o.z,yaw:o.yaw}));
  const blocks=Object.entries(world.blocks).map(([k,b])=>[...k.split(',').map(Number),b]);
  send(c,{t:'welcome',id:c.id,seed:world.seed,blocks,players});
  clients.set(c.id,c);bcast({t:'join',id:c.id,name:c.name,x:c.x,y:c.y,z:c.z,yaw:c.yaw},c);
  console.log(c.name+' entrou ('+clients.size+' online)');
 }else if(!c.joined)return;
 else if(m.t=='pos'){const[x,y,z,yaw]=[+m.x,+m.y,+m.z,+m.yaw];if([x,y,z,yaw].some(v=>!isFinite(v)))return;Object.assign(c,{x,y,z,yaw});bcast({t:'pos',id:c.id,x,y,z,yaw},c)}
 else if(m.t=='blk'){const x=m.x|0,y=m.y|0,z=m.z|0,b=m.b|0;if(x<0||x>=108||z<0||z>=108||y<0||y>=32||b<0||b>30)return;
  if(Object.keys(world.blocks).length>300000)return;world.blocks[x+','+y+','+z]=b;dirty=true;bcast({t:'blk',x,y,z,b},c)}}
function parse(c){for(;;){const b=c.buf;if(b.length<2)return;const fin=b[0]&128,op=b[0]&15,mask=b[1]&128;let len=b[1]&127,off=2;
 if(len==126){if(b.length<4)return;len=b.readUInt16BE(2);off=4}else if(len==127){if(b.length<10)return;len=Number(b.readBigUInt64BE(2));off=10}
 if(len>1e6){drop(c);return}const mk=mask?4:0;if(b.length<off+mk+len)return;
 let pl=Buffer.from(b.slice(off+mk,off+mk+len));if(mask){const k=b.slice(off,off+4);for(let i=0;i<pl.length;i++)pl[i]^=k[i%4]}
 c.buf=b.slice(off+mk+len);
 if(op==8){try{c.socket.end(frame(8,Buffer.alloc(0)))}catch(_){}drop(c);return}
 if(op==9){c.socket.write(frame(10,pl));continue}
 if(op==1||op==0||op==2){c.frag.push(pl);if(fin){const t=Buffer.concat(c.frag).toString();c.frag=[];handle(c,t)}}}}
server.on('upgrade',(req,socket)=>{
 const key=req.headers['sec-websocket-key'];if(!key){socket.destroy();return}
 const acc=crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
 socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+acc+'\r\n\r\n');
 socket.setNoDelay(true);const c={socket,id:0,name:'',buf:Buffer.alloc(0),frag:[],joined:false,dead:false,x:50,y:20,z:40,yaw:0,win:0,cnt:0};
 socket.on('data',d=>{c.buf=Buffer.concat([c.buf,d]);parse(c)});socket.on('close',()=>drop(c));socket.on('error',()=>drop(c))});
server.listen(PORT,'0.0.0.0',()=>{console.log('Sobrevivência 3D online na porta '+PORT);
 for(const l of Object.values(os.networkInterfaces()))for(const i of l)if(i.family=='IPv4'&&!i.internal)console.log('  na rede local:  http://'+i.address+':'+PORT+'   (no jogo use ws://'+i.address+':'+PORT+')')});
